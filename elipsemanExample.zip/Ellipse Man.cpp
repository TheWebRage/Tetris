#include <cstdlib>
#include <iostream>
#include "graphics.h"
#include <fstream>
using namespace std;
int maxEllipse = 19;
class EllipseMan
{     public:
      EllipseMan();
      EllipseMan(int, int, int, int, int, int, int, int, int, int, int, int, int);
           int HorizontalCenter, VerticalCenter, HorizontalRadius, VerticalRadius, StartAngle, EndAngle, OutlineRed, OutlineGreen, OutlineBlue, FillRed, FillGreen, FillBlue, fill;
           void display();
           void setValues(int hc, int vc, int sa, int ea, int hr, int vr, int orr, int og, int ob, int fr, int fg, int fb, int f);
      private:
           int myHorizontalCenter, myVerticalCenter, myHorizontalRadius, myVerticalRadius, myStartAngle, myEndAngle,myOutlineRed, myOutlineGreen, myOutlineBlue, myFillRed, myFillGreen, myFillBlue, myfill;
};
EllipseMan :: EllipseMan()
: myHorizontalCenter(1), myVerticalCenter(1), myHorizontalRadius(1), myVerticalRadius(1), myStartAngle(1), myEndAngle(1),myOutlineRed(1), myOutlineGreen(1), myOutlineBlue(1), myFillRed(1), myFillGreen(1), myFillBlue(1), myfill(1)
{  }
EllipseMan :: EllipseMan(int hc, int vc, int hr, int vr, int sa, int ea, int orr, int og, int ob, int fr, int fg, int fb, int f)
: myHorizontalCenter(hc), myVerticalCenter(vc), myHorizontalRadius(hr), myVerticalRadius(vr), myStartAngle(sa), myEndAngle(ea),myOutlineRed(orr), myOutlineGreen(og), myOutlineBlue(ob), myFillRed(fr), myFillGreen(fg), myFillBlue(fb), myfill(f)
{  }
void EllipseMan :: display()
{
     setcolor(COLOR(myOutlineRed, myOutlineGreen, myOutlineBlue));
     if(myfill == 1)
     {
          setfillstyle(1, COLOR(myFillRed, myFillGreen, myFillBlue));
          fillellipse(myHorizontalCenter, myVerticalCenter, myHorizontalRadius, myVerticalRadius); 
     }
     else if(myfill == 0)
     {  
          ellipse(myHorizontalCenter, myVerticalCenter, myStartAngle, myEndAngle, myHorizontalRadius, myVerticalRadius);
     }
}
void EllipseMan :: setValues(int hc, int vc, int sa, int ea, int hr, int vr,int orr, int og, int ob, int fr, int fg, int fb, int f)
{
     myHorizontalCenter = hc, myVerticalCenter = vc, myHorizontalRadius = hr, myVerticalRadius = vr, myStartAngle = sa, myEndAngle = ea, myOutlineRed = orr, myOutlineGreen = og, myOutlineBlue = ob, myFillRed = fr, myFillGreen = fg, myFillBlue = fb, fill = f;
}
int main(int argc, char *argv[])
{
    EllipseMan EllipseManArray[19];
    initwindow(640, 480);
    int hc, vc, hr, vr, sa, ea, orr, og, ob, fr, fg, fb, f;
    fstream fileIn("EllipseMan.dat");
           for(int count = 0; count < maxEllipse; count++)
           {
                fileIn>>hc>>vc>>sa>>ea>>hr>>vr>>orr>>og>>ob>>fr>>fg>>fb>>f;
                EllipseManArray[count].setValues(hc, vc, sa, ea, hr, vr, orr, og, ob, fr, fg, fb, f);
                EllipseManArray[count].display();
           }  
    system("PAUSE");
    return EXIT_SUCCESS;
}
